from temboo.Library.Facebook.Actions.General.Likes.CreateLike import CreateLike, CreateLikeInputSet, CreateLikeResultSet, CreateLikeChoreographyExecution
from temboo.Library.Facebook.Actions.General.Likes.DeleteLike import DeleteLike, DeleteLikeInputSet, DeleteLikeResultSet, DeleteLikeChoreographyExecution
from temboo.Library.Facebook.Actions.General.Likes.ReadLikes import ReadLikes, ReadLikesInputSet, ReadLikesResultSet, ReadLikesChoreographyExecution
from temboo.Library.Facebook.Actions.General.Likes.UpdateLike import UpdateLike, UpdateLikeInputSet, UpdateLikeResultSet, UpdateLikeChoreographyExecution
