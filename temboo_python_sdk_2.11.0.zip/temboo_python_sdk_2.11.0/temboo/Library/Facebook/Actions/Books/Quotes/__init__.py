from temboo.Library.Facebook.Actions.Books.Quotes.CreateQuote import CreateQuote, CreateQuoteInputSet, CreateQuoteResultSet, CreateQuoteChoreographyExecution
from temboo.Library.Facebook.Actions.Books.Quotes.DeleteQuote import DeleteQuote, DeleteQuoteInputSet, DeleteQuoteResultSet, DeleteQuoteChoreographyExecution
from temboo.Library.Facebook.Actions.Books.Quotes.ReadQuotes import ReadQuotes, ReadQuotesInputSet, ReadQuotesResultSet, ReadQuotesChoreographyExecution
from temboo.Library.Facebook.Actions.Books.Quotes.UpdateQuote import UpdateQuote, UpdateQuoteInputSet, UpdateQuoteResultSet, UpdateQuoteChoreographyExecution
