from temboo.Library.Facebook.Actions.Fitness.Bikes.CreateBike import CreateBike, CreateBikeInputSet, CreateBikeResultSet, CreateBikeChoreographyExecution
from temboo.Library.Facebook.Actions.Fitness.Bikes.DeleteBike import DeleteBike, DeleteBikeInputSet, DeleteBikeResultSet, DeleteBikeChoreographyExecution
from temboo.Library.Facebook.Actions.Fitness.Bikes.ReadBikes import ReadBikes, ReadBikesInputSet, ReadBikesResultSet, ReadBikesChoreographyExecution
from temboo.Library.Facebook.Actions.Fitness.Bikes.UpdateBike import UpdateBike, UpdateBikeInputSet, UpdateBikeResultSet, UpdateBikeChoreographyExecution
