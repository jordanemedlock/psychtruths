from temboo.Library.Facebook.Actions.Fitness.Walks.CreateWalk import CreateWalk, CreateWalkInputSet, CreateWalkResultSet, CreateWalkChoreographyExecution
from temboo.Library.Facebook.Actions.Fitness.Walks.DeleteWalk import DeleteWalk, DeleteWalkInputSet, DeleteWalkResultSet, DeleteWalkChoreographyExecution
from temboo.Library.Facebook.Actions.Fitness.Walks.ReadWalks import ReadWalks, ReadWalksInputSet, ReadWalksResultSet, ReadWalksChoreographyExecution
from temboo.Library.Facebook.Actions.Fitness.Walks.UpdateWalk import UpdateWalk, UpdateWalkInputSet, UpdateWalkResultSet, UpdateWalkChoreographyExecution
