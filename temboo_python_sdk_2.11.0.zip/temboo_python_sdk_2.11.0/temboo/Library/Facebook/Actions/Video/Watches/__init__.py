from temboo.Library.Facebook.Actions.Video.Watches.CreateWatch import CreateWatch, CreateWatchInputSet, CreateWatchResultSet, CreateWatchChoreographyExecution
from temboo.Library.Facebook.Actions.Video.Watches.DeleteWatch import DeleteWatch, DeleteWatchInputSet, DeleteWatchResultSet, DeleteWatchChoreographyExecution
from temboo.Library.Facebook.Actions.Video.Watches.ReadWatch import ReadWatch, ReadWatchInputSet, ReadWatchResultSet, ReadWatchChoreographyExecution
from temboo.Library.Facebook.Actions.Video.Watches.UpdateWatch import UpdateWatch, UpdateWatchInputSet, UpdateWatchResultSet, UpdateWatchChoreographyExecution
