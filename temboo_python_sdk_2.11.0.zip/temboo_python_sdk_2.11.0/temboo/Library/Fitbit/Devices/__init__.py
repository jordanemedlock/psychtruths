from temboo.Library.Fitbit.Devices.AddAlarm import AddAlarm, AddAlarmInputSet, AddAlarmResultSet, AddAlarmChoreographyExecution
from temboo.Library.Fitbit.Devices.DeleteAlarm import DeleteAlarm, DeleteAlarmInputSet, DeleteAlarmResultSet, DeleteAlarmChoreographyExecution
from temboo.Library.Fitbit.Devices.GetAlarms import GetAlarms, GetAlarmsInputSet, GetAlarmsResultSet, GetAlarmsChoreographyExecution
from temboo.Library.Fitbit.Devices.GetDevices import GetDevices, GetDevicesInputSet, GetDevicesResultSet, GetDevicesChoreographyExecution
from temboo.Library.Fitbit.Devices.UpdateAlarm import UpdateAlarm, UpdateAlarmInputSet, UpdateAlarmResultSet, UpdateAlarmChoreographyExecution
